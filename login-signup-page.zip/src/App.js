import logo from "./logo.svg";
import "./App.css";
import { Loginsignup } from "./Component/Loginsign/Loginsignup";

function App() {
  return (
    <div>
      <Loginsignup />
    </div>
  );
}

export default App;
